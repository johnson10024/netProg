<!DOCTYPE html>
<html>
<head>
	<title>upload</title>
</head>
<body>
<p>uploading</p>

<?php

echo "AAA";
$target_dir = "uploads/";
$target_file = $target_dir . basename($_FILES["upfile"]["name"]);
$ok = 1;
echo "sadfasf";
if(file_exists($target_file))
{
	echo "File already Exists!!";
	$ok = 0;
}

if($ok !== 0)
{
	echo "AAAAAA";
	if(move_uploaded_file($_FILES["upfile"]["name"], $target_file))
	{
		echo "Upload Succesfully";
	}
	else echo "Upload failed";
}

?>

</body>
</html>
