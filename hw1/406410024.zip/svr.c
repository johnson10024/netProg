#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/sendfile.h>
#include <netinet/in.h>
#include <netdb.h>
#include <arpa/inet.h>
#include <string.h>
#include <sys/stat.h>
#include <fcntl.h>

#define HTM "index.html"
#define ASP "default.aspx"
#define BUFFSZ 4096

FILE *inp, *out;
char headers[] = 
"HTTP/1.1 200 OK\r\n"
"Content-type: text/html; charset=UTF-8\r\n\r\n";
char buff_out[4096];
char file_name[4096];
char *html_out[4096];
char *php_out[4096];

void readIndex();
int lineIndex;
int linePhp;

int main(int argc, char **argv)
{

	struct sockaddr_in svr_addr, cli_addr;
	socklen_t sin_len = sizeof(cli_addr);

	int svr_fd, cli_fd, img_fd;
	int on = 1;

	char buff[8192];

	svr_fd = socket(AF_INET, SOCK_STREAM, 0);
	if(svr_fd < 0)
	{
		perror("Socket Failed\n");
		exit(1);
	}

	setsockopt(svr_fd, SOL_SOCKET, SO_REUSEADDR, &on, sizeof(int));

	svr_addr.sin_family = AF_INET;
	svr_addr.sin_addr.s_addr = INADDR_ANY;
	svr_addr.sin_port = htons(8085);

	if(bind(svr_fd, (struct sockaddr *) &svr_addr, sizeof(svr_addr)) == -1)
	{
		perror("Bind Failed\n");
		close(svr_fd);
		exit(1);
	}

	if(listen(svr_fd, 10) == -1)
	{
		perror("Listen Failed\n");
		close(svr_fd);
		exit(1);
	}

	pid_t pid;
	readIndex();

	while(1)
	{
		cli_fd = accept(svr_fd, (struct sockaddr *) &cli_addr, &sin_len);

		if(cli_fd == -1)
		{
			perror("Connection Failed\n");
			continue;
		}

		printf("Connected\n");

		pid = fork();

		if(pid == 0)
		{
			close(svr_fd);
			memset(buff, 0, sizeof(buff));
			read(cli_fd, buff, sizeof(buff) - 1);

			printf("%s\n", buff);
			
			
			if(strncmp(buff, "GET /pic.png", 12) == 0)
			{
				sprintf(file_name, "HTTP/1.1 200 OK\r\nContent-Type: image/png\r\n\r\n");
				write(cli_fd, file_name, strlen(file_name));

				img_fd = open("pic.png", O_RDONLY);
				sendfile(cli_fd, img_fd, NULL, 257600);
				close(img_fd);
			}
			else if(strncmp(buff, "GET / ", 6) == 0)
			{
				//Write Headers
				write(cli_fd, headers, sizeof(headers) - 1);
				for(int i = 0; i < lineIndex; i++)
				{
					write(cli_fd, html_out[i], strlen(html_out[i]));
				}				
			}
			else if(strncmp(buff, "POST /up", 6) == 0)
			{
				write(cli_fd, headers, sizeof(headers) - 1);
				char ibuff[4096];
				char bound[100];
				char PATH[BUFFSZ] = "uploads/";
				char *cur;
				int length = 0;
				int start = -1;
				int flag_out = 0;

				cur = strstr(buff, "boundary");
				strtok(cur, " \r\n");
				strcpy(bound, cur + 9);
				
				while((cur = strtok(NULL, " \r\n")) != NULL)
				{
					if(strstr(cur, bound) != NULL) length++;
					if(length == 2) break;

					if(strncmp(cur, "filename", 8) == 0)
					{
						sscanf(cur + 10, "%s", file_name);
						file_name[strlen(file_name) - 1] = 0;
						strcat(PATH, file_name);
printf("==============%s\n", PATH);
						out = fopen(PATH, "w");
					}


					if(flag_out == 1)
					{
						fprintf(out, "%s", cur);
					}
//printf("=%s %d\n", cur, length);
					if(strncmp(cur, "text/plain", 10) == 0) flag_out = 1;
				}
				fclose(out);
			}
			else if(strncmp(buff, "GET /fav", 8) == 0)
			{
				write(cli_fd, headers, sizeof(headers) - 1);
			}
	
			printf("Closing\n\n\n");
			exit(0);
		}
		else
		{
			close(cli_fd);
		}
	}

	return 0;
}

void readIndex()
{
	char ibuff[4096];
	lineIndex = 0;
	inp = fopen(HTM, "r");

	while(fgets(ibuff, 4096, inp) != NULL)
	{
		html_out[lineIndex] = (char *)malloc(sizeof(char) * (strlen(ibuff) + 1));
		strcpy(html_out[lineIndex], ibuff);
		lineIndex++;
	}

	fclose(inp);
}

